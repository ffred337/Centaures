/*
-- =========================================================================== A
-- TS_imm.sql
-- ---------------------------------------------------------------------------
Activit� : IFT187_2022-2 PROJET BASE DE DONNEES
Encodage : UTF-8 sans BOM, fin de ligne Unix (LF)
Plateforme : PostgreSQL 9.6 � 14.1
Responsables : LORINCE TAWAMBA, LUC LAVOIE
Version : V0.1
Statut : en d�veloppement
R�sum� : Cr�ation script pour IMM de Centaures (boutique d'achat en ligne)
-- =========================================================================== A
*/

/* Norder*/
create or replace procedure Order(_idP Produit_id)
language sql as
$$
delete from Commande where exists (select id_produit from Commande where id_produit = _idP);
$$;

/* SetPrice*/
create or replace procedure SetPrice(_idP Produit_id, price float)
language sql as
$$
update Produits set pu_produit = price where id_produit = _idP;
$$;

/* rmProduct*/
create or replace procedure rmProduct(_idP Produit_id)
language sql as 
$$
delete from Produits where id_produit = _idP);
$$;


/* rmCat*/
create or replace procedure rmCat(_idC Categorie_id)
language sql as 
$$
delete from Produits where id_produit = _idP);
$$;


/* SetQte*/
create or replace procedure SetQte(_idP Produit_id, _qte int)
language sql as
$$
update Commande set qte = _qte  where id_produit = _idP;
$$;


/* SetNum*/
create or replace procedure SetNum(_num)
language sql as
$$
update Commande set num_commande = _num;
$$;

/* SetTranspo*/
create or replace procedure SetTranspo(_idT Transporteur_id, idCol Colis_id)
language sql as
$$
update Colis set id_transpo = _idT where id_colis = idCol;
$$;

/* Qte_lim   v�rifie si les limites logique de fixation de quantit� d'un produit command� sont prix sont respect�es(qte strictement sup�rieur � z�ro)'*/
create or replace function Qte_lim()
returns trigger
language plpgsql as $$
    BEGIN
    if exists (select * from commande where qte <= 0) then
         raise exception 'Vous ne pouvez  commander un produit de qte nulle ou n�gative';
        else
       return null;
    end if;
end;
$$

/* Qte_dec_lim   appele la pr�c�dente apr�s une insertion ou une mis � jour dans Commande*/
create trigger Qte_dec_lim
    after insert or update on commande
    execute procedure Qte_lim();

/*Colis
-le transporteur doit avoir l'adresse de livraison ,le code du colis,la destination
-le propri�taire doit voir le nom du destinataire,le contenu de la commande et le prix total
l'adresse du destintaire,l'id du transporteur,son nom,la date de livraison et l'heure

*/
CREATE VIEW TransCo (adresse,code_colis)
AS SELECT adresse ,code_colis
FROM colis;

CREATE VIEW ProCo (nom_client ,nom_produit,PU,produit_id,adresse,id_transpo,date_livraison)
AS SELECT nom_client ,nom_produit,PU,produit_id,adresse,id_transpo,date_livraison
FROM colis NATURAL JOIN bon_commande NATURAL JOIN bon_livraison;

/*Facture
-id du produit
-nom du produit
-la quantit�
-le prix total 
-le cout total de la commande
-cout de la livraison 
-mode de payement*/

SELECT code_colis,nom_commande,qte_commande,tarif_ville
FROM colis NATURAL JOIN ville NATURAL JOIN bon_commande ;


/*
-- =========================================================================== Z
Contributeurs :

  (NV) VICTOIRE NTCHUINGWA 
  (SW) SERGINE WELLAN 
  (BM) BORISKA MBILONGO
  (FT) FRED TCHIADEU  

Adresse, droits d'auteur et copyright :
  INSTITUT UCAC-ICAM X2026

T�ches projet�es :
  NIL

T�ches r�alis�es :
  2022-06-15 (XX) : Cr�ation



-- ---------------------------------------------------------------------------
-- TS_imm.sql
-- =========================================================================== Z
*/