/* GROUPE 12 */

Les documents joints à ce fichier sont les composants constitutifs du Jalon 2 effectué par le groupe 12.

Les noms qui suivent sont ceux des membres de ce groupes :

-•  WELLAN SERGINE (CHEF  PROJET)
-•  MBILONGO BORISKA
-•  NTCHUINGWA VICTOIRE
-•  TCHIADEU FRED 


/* GROUPE 12 */
